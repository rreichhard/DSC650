---
title: Assignment 1
subtitle: Computer performance, reliability, and scalability calculation
author: Jane Doe
---

## 1.2 

#### a. Data Sizes

| Data Item                                  | Size per Item | 
|--------------------------------------------|--------------:|
| 128 character message.                     | 128 Bytes     | https://bellevue-university.github.io/dsc650/lessons/fundamentals/size/
| 1024x768 PNG image                         | 2.36 MB       | https://www.omnicalculator.com/other/image-file-size#how-to-calculate-image-file-size 
| 1024x768 RAW image                         | 1.17 MB       | 1024x768x12=9437184 / 8 = 1179648 bytes
| HD (1080p) HEVC Video (15 minutes)         | 300 MB        | https://www.circlehd.com/blog/how-to-calculate-video-file-size 20x15
| HD (1080p) Uncompressed Video (15 minutes) | 167962 MB     | assuming framerate 30 fps & 8 bit https://www.omnicalculator.com/other/video-size
| 4K UHD HEVC Video (15 minutes)             | 12.6 MB       | 84x15
| 4k UHD Uncompressed Video (15 minutes)     | 167962 MB     | assuming framerate 30 fps & 8 bit https://www.omnicalculator.com/other/video-size
| Human Genome (Uncompressed)                | 200 GB        | https://medium.com/precision-medicine/how-big-is-the-human-genome-e90caa3409b0

#### b. Scaling

|                                           | Size     | # HD | 
|-------------------------------------------|---------:|-----:|
| Daily Twitter Tweets (Uncompressed)       | .192 TB  | 1    | 128 bytes * 500 million = 0.064 TB, x 3
| Daily Twitter Tweets (Snappy Compressed)  | 0.96 TB  | 1    | 2-4x for HTML
| Daily Instagram Photos                    | 531 TB   | 6    |  531,000,000 	 100,000,000 	 75,000,000 	 1024X768 PNG 	2.36
| Daily YouTube Videos                      | 1.8 TB   | 1    | 300 MB for every 15 minutes, * 4 for amount per hour	1200 MB per hour * 500 hours	600000 MB, x3 for hadoop
| Yearly Twitter Tweets (Uncompressed)      | 70 TB    | 7    | .192 TB * 365
| Yearly Twitter Tweets (Snappy Compressed) | 35 TB    | 4    | .096 * 365
| Yearly Instagram Photos                   | 193815 TB| 19382| 531 TB * 365
| Yearly YouTube Videos                     | 657 TB   |  66  | 1.8 TB * 365


#### c. Reliability
|                                    | # HD | # Failures |
|------------------------------------|-----:|-----------:|
| Twitter Tweets (Uncompressed)      | 7    |  1         |
| Twitter Tweets (Snappy Compressed) | 4    |  1         |
| Instagram Photos                   | 19382| 318        |
| YouTube Videos                     | 66   |  1         |

#### d. Latency

|                           | One Way Latency      |
|---------------------------|---------------------:|
| Los Angeles to Amsterdam  | 148 ms               |https://wondernetwork.com/pings
| Low Earth Orbit Satellite | 240 ms               |https://www.satsig.net/latency.htm
| Geostationary Satellite   | 280 ms               |
| Earth to the Moon         | 1300 ms              |https://www.sciencedaily.com/releases/2017/06/170621145130.htm#:~:text=The%20answer%20is%20simple%3A%20space,distance%20between%20the%20two%20planets.
| Earth to Mars             | 21 minutes           | https://blogs.esa.int/mex/2012/08/05/time-delay-between-mars-and-earth/

